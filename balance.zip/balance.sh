
#!/bin/bash
templete_server="server %s  0.0.0.0:%s check inter 2000 fall 5 rise 1 weight 30"
PORT=0
haproxyconfig="/etc/myhaproxy"
ssrconfig="shadowsocksrwjs"
function Listening {
   TCPListeningnum=`netstat -an | grep ":$1 " | awk '$1 == "tcp" && $NF == "LISTEN" {print $0}' | wc -l`
   UDPListeningnum=`netstat -an | grep ":$1 " | awk '$1 == "udp" && $NF == "0.0.0.0:*" {print $0}' | wc -l`
   (( Listeningnum = TCPListeningnum + UDPListeningnum ))
   if [ $Listeningnum == 0 ]; then
       echo "0"
   else
       echo "1"
   fi
}

function get_random_port {
   PORT=0
   while [ $PORT==0 ]
   do
       temp1="2"$(head -n 128 /dev/urandom | tr -dc "123456789" | head -c4)
       if [ `Listening $temp1` == 0 ] ; then
              PORT=$temp1
              echo $PORT
              break
       fi
       
   done
}

##########################v2ray action#######################################################
v2ray_start(){
	`/usr/bin/v2ray/v2ray -config  $1$2;`
}
v2ray_stop(){
	`ps -ef | grep v2ra[y] | awk '{print $1}' |xargs kill -9`
}
show_all_v2ray(){
  ps -ef | grep 'v2ray/v2ra[y]'
  echo "v2ray client count:"$(ps -ef | grep v[2] | wc -l)
		
}

start_all_v2ray(){
    read -p 'input the configs folder:' folder
    softfiles=$(ls $folder)
    for sfile in ${softfiles}
    do
        v2ray_start  ${folder} ${sfile} &
        echo ${folder}${sfile} "started"
        sleep 1
    done
    show_all_v2ray
}

####################################config generate##########################################################
gen_ssr_config(){
    cp /etc/config/shadowsocksr /etc/config/tmpfq
    awk -v RS="config servers" '{n+=1;b="config servers "n "_json";printf $0b}' /etc/config/tmpfq   >/etc/config/${ssrconfig}
    for fes in $(cat /etc/config/${ssrconfig}  | grep "[1-9]\{1,2\}_json" -o)
    do
      if [ $(uci get ${ssrconfig}.$fes.server) != '127.0.0.1' ];then
          uci set ${ssrconfig}.$fes.localproto='socks'
          uci set ${ssrconfig}.$fes.local_port=$(get_random_port)
      fi
    done
    uci commit ${ssrconfig}
}

gen_v2_configs(){
    read -p "input the dir your v2 configs:" v2raydir
    if [ ! -d "$v2raydir" ]; then
            mkdir $v2raydir
    fi
    for fes in $(cat /etc/config/${ssrconfig} | grep "[1-9]\{1,2\}_json" -o)
    do
      if [ $(uci get ${ssrconfig}.$fes.server) != '127.0.0.1' ];then
          configname=${fes/_/.}
    	    lua $(cd "$(dirname "$0")";pwd)"/genv2rayconfig.lua" $fes tcp $(uci get ${ssrconfig}.$fes.local_port)> ${v2raydir}${configname}
          echo "config filename:"${v2raydir}${configname} 
       else
         echo $(uci get ${ssrconfig}.$fes.server) 
       fi
       
    done

}


gen_hap_config(){
    read -p 'input the v2ray configs folder:' folder
    configfiles=$(ls $folder)
    myserver=""
    for fes in $(cat /etc/config/${ssrconfig}  | grep "[1-9]\{1,2\}_json" -o)
    do
        if [ $(uci get ${ssrconfig}.$fes.server) != '127.0.0.1' ];then
            port=$(uci get ${ssrconfig}.$fes.local_port)
            servername=$(uci get ${ssrconfig}.$fes.server)
            randomint=$(head -n 128 /dev/urandom | tr -dc "0123456789" | head -c3)
            echo ${servername}:${port}
            oneserver=$(printf  "\t${templete_server}\n"  "${servername}-${randomint}" "${port}" )
            myserver=$(echo -n -e "${myserver}\n${oneserver}")
        fi 
       
    done
cat > "${haproxyconfig}" << EOF
global
  maxconn 150000
  nbproc  1
  daemon

defaults
        mode tcp
        retries 5
        option  abortonclose
        maxconn 32000
        timeout connect 300000ms
        timeout client  300000ms
        timeout server  300000ms
        log 127.0.0.1   local0 err


listen win_ss 
        bind 0.0.0.0:20000
        mode tcp
        balance roundrobin
${myserver}
listen status
    bind 0.0.0.0:1188
    mode http                   
    stats refresh 6s
    stats uri  /  
    stats auth admin:admin
    #stats hide-version
    stats admin if TRUE
EOF

}

################################################################
start_haproxy(){
    haproxy -f $haproxyconfig
    echo `ps -ef | grep "$haproxyconfig"`
}

start_haproxy(){
    haproxy -f $haproxyconfig
}
stop_haproxy(){
  ps -ef | grep "${haproxyconfig}" | awk '{print $1}' |xargs kill -9
}
start_menu(){
clear
echo "
1, start multi v2ray
2, stop all v2ray
3, show all v2ray pid

4, generate ssr config


5, generate the v2rays(input the example:/etc/test/)
6, generate the haproxy config file

7,start the haproxy server
8,stop the haproxy server
"
read -p "please enter the num you choice[1,2,3,4,5]:" num
case $num in
	1)
	start_all_v2ray
	;;
	2)
	v2ray_stop
	;;
	3)
	show_all_v2ray
	;;
  4)
  gen_ssr_config
  ;;
	5)
  	gen_v2_configs
  	;;
  	6)
  	gen_hap_config
  	;;
   7) 
   start_haproxy
   ;;
   8)
   stop_haproxy
   ;;
	*)
	clear
	echo -e "input 1,2 or 3"
	sleep 1s
	start_menu
	;; 
esac
}
start_menu

